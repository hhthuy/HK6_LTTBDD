package com.se.propertiesdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertiesDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
