package com.se.stringbootjpacruddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringbootJpaCrudDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
