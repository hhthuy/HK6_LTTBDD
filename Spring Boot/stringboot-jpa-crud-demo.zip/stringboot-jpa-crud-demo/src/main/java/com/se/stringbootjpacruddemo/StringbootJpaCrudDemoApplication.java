package com.se.stringbootjpacruddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StringbootJpaCrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StringbootJpaCrudDemoApplication.class, args);
	}

}
