package com.se.stringboothibernatecruddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StringbootHibernateCrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StringbootHibernateCrudDemoApplication.class, args);
	}

}
