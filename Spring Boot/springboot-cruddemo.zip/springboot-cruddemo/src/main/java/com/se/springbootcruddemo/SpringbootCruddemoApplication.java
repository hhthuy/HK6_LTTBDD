package com.se.springbootcruddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCruddemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCruddemoApplication.class, args);
	}

}
