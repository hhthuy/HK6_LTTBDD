package com.se.springdatarestcruddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataRestCrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataRestCrudDemoApplication.class, args);
	}

}
