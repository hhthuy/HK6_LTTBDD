package com.se.stringbootdatajpacruddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StringbootDataJpaCrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StringbootDataJpaCrudDemoApplication.class, args);
	}

}
