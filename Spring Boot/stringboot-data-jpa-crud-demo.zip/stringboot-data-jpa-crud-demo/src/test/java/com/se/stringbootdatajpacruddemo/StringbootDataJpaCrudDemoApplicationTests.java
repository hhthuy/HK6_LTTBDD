package com.se.stringbootdatajpacruddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringbootDataJpaCrudDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
