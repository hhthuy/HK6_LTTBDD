package com.se.springdatarestcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataRestCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
