package com.se.springdatarestcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataRestCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataRestCrudApplication.class, args);
	}

}
